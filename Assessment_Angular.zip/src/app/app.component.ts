import { EmpServiceService } from './employee.service';
// import { EmployeeTitlePipe } from './EmployeeTitle.pipe';
 import { Employee, Employees } from './Department';
import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'pipesdemo';
  emplist:any;

  constructor()
  {
    this.emplist=Employees;
  }
}