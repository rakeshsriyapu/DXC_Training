
import { HttpClient } from '@angular/common/http';
import { Employee, Employees } from './Department';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class EmpServiceService {
private emplist:Employee[]=[
  {id:1,name:'Engineering',g_name:'Research and Development',mod_date:new Date('8/10/1987')},
    {id:2,name:'Tool Design',g_name:'Research and Development',mod_date:new Date('8/10/1987')},
    {id:3,name:'Sales',g_name:'Sales and Marketing',mod_date:new Date('8/10/1987')},
    {id:4,name:'Marketing',g_name:'Sales and Marketing',mod_date:new Date('8/10/1987')},
    {id:5,name:'Purchasing',g_name:'Inventory Management',mod_date:new Date('8/10/1987')},
];
  constructor() {
    }
  getEmployees(){
return this.emplist;
  }

  save(emp:Employee)
  {
    this.emplist.push(emp);
  }
  update(emp:Employee,index:number)
  {
     this.emplist[index]=emp;
      }
  delete(index :number)
  {
    this.emplist.splice(index,1);
  }
}