
import { Router } from '@angular/router';
import { Employee } from './Department';
import { EmpServiceService } from './employee.service';
import { Component, OnInit, Input } from '@angular/core';
import {HttpClient} from '@angular/common/http';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.scss']
})
export class ListComponent implements OnInit {
  employee:Employee;
  updatediv=false;
  indexposition:number;
emplist :Employee[];

  constructor(private es:EmpServiceService,private route :Router){
    this.emplist=this.es.getEmployees();
    }
  ngOnInit(){
  //this.employee=this.emplist[0];
  }
  edit(index:number)
  {   
    console.log("Index "+index);
     this.updatediv=true; 
     this.employee=this.emplist[index];
    //  console.log(this.emplist[index]);
    this.es.update(this.employee,this.indexposition);  
   }
  deleteEmplyee(index:number)
  {
    this.es.delete(index);
   }
}