
import { Router } from '@angular/router';
import { EmpServiceService } from './employee.service';
import { Employee } from './Department';
import { Component, OnInit ,Input} from '@angular/core';

@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.scss']
})
export class UpdateComponent implements OnInit {
Emp:Employee;
updatedindex:number;
@Input()

  rowindex:number;

  constructor(private es:EmpServiceService,private route:Router) {
    
   }

  ngOnInit() {
    // this.rowindex
    console.log(this.rowindex)
  }
  updateEmployee(index:number)
  {
    
  }
}