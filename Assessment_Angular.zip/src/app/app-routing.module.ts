import { UpdateComponent } from './update.component';
import { CreateComponent } from './create.component';
import { ListComponent } from './list.component';
import { AppComponent } from './app.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';


const routes: Routes = [
  {path:'',component:AppComponent},
  {path:'list',component:ListComponent},
  {path:'create',component:CreateComponent},
   {path:'edit',component:UpdateComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }