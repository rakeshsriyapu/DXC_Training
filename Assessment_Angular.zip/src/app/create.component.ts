import { Employee } from './Department';
import { EmpServiceService } from './employee.service';
import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import {NgForm} from '@angular/forms';


@Component({
  selector: 'app-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.scss']
})
export class CreateComponent implements OnInit {
 
employee=new Employee();
  constructor(private es:EmpServiceService,
    private route:Router) {
  }

  ngOnInit() {  }
saveEmployee():void{
this.es.save(this.employee);
console.log(this.employee)
  this.route.navigate(['list']);
}
updateEmployee():void{
  this.es.save(this.employee);
    this.route.navigate(['list']);
  }
}