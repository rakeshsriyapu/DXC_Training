export class Employee{
    id:number;
    name:string;
    g_name:string;
    mod_date:Date;
    
}
export const Employees:Employee[]=[
    {id:1,name:'Engineering',g_name:'Research and Development',mod_date:new Date()},
    {id:2,name:'Tool Design',g_name:'Research and Development',mod_date:new Date('8/10/1987')},
    {id:3,name:'Sales',g_name:'Sales and Marketing',mod_date:new Date('8/10/1987')},
    {id:4,name:'Marketing',g_name:'Sales and Marketing',mod_date:new Date('8/10/1987')},
    {id:5,name:'Purchasing',g_name:'Inventory Management',mod_date:new Date('8/10/1987')},
];