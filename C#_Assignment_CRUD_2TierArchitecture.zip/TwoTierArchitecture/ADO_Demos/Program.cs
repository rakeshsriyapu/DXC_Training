﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeDAL;

namespace ADO_Demos
{
    class Program
    {
        Employee employee;
        static void Main(string[] args)
        {
            Program p = new Program();
            //p.getEmployeeDetail();
            //p.updateEmployeeDetail();
            //p.deleteEmployeeDetail();
            p.readEmployee();
            Console.ReadLine();

        }
        public void getEmployeeDetail()
        {
            Console.WriteLine("Enter ID,    Name, Gender, Location and Salary");
            employee = new Employee();
            employee.Id = int.Parse(Console.ReadLine());
            employee.Name = Console.ReadLine();
            employee.Gender = Console.ReadLine();
            employee.Location = Console.ReadLine();
            employee.Salary = int.Parse(Console.ReadLine());
            int row_count=employee.InsertNewEmployee(employee);
            if(row_count>0)
            {
                Console.WriteLine(row_count + " rows affected");
            }
        }
        public void updateEmployeeDetail()
        {
            employee = new Employee();

            Console.WriteLine("Enter the ID to Update");
            employee.Id = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter Name, Gender, Location and Salary to Update");
            employee.Name = Console.ReadLine();
            employee.Gender = Console.ReadLine();
            employee.Location = Console.ReadLine();
            employee.Salary = int.Parse(Console.ReadLine());

            int row_count = employee.UpdateNewEmployee(employee);
            if (row_count > 0)
            {
                Console.WriteLine(row_count + " rows affected");
            }

        }

        public void deleteEmployeeDetail()
        {
            employee = new Employee();
            Console.WriteLine("Enter the ID to Delete");
            employee.Id = int.Parse(Console.ReadLine());


            int row_count = employee.DeleteEmployee(employee);
            if (row_count > 0)
            {
                Console.WriteLine(row_count + " rows affected");
            }
        }

        public void readEmployee()
        {
            employee = new Employee();
            employee.ReadEmployee(employee);
        }
    }
}
