﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace EmployeeDAL
{
    public class Employee
    {
        private int id,salary;
        string name, gender, location;
        SqlConnection con = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        string connstr = "data source=IN5CG9214YJZ;database=ADO_Demo;integrated security=true;";

        public int Salary { get => salary; set => salary = value; }
        public string Name { get => name; set => name= value; }
        public string Gender { get => gender; set => gender = value; }
        public string Location { get => location; set => location = value; }
        public int Id { get => id; set => id = value; }

        public int InsertNewEmployee(Employee employee)
        {
            cmd.Connection = con; //Used to establish connection to database
            con.ConnectionString = connstr;
            cmd.CommandType = System.Data.CommandType.StoredProcedure; //To inform the compiler that we will be passing stored procedure
            //Stored procedure gives performance enhancement
            cmd.CommandText = "sp_InsertNewEmployee";
            cmd.Parameters.AddWithValue("id", employee.Id);
            cmd.Parameters.AddWithValue("name", employee.Name);
            cmd.Parameters.AddWithValue("gender", employee.Gender);
            cmd.Parameters.AddWithValue("location", employee.Location);
            cmd.Parameters.AddWithValue("salary", employee.Salary);
            con.Open();
            int rowcount = cmd.ExecuteNonQuery();
            con.Close();
            return rowcount;
        }

        public int UpdateNewEmployee(Employee employee)
        {
            cmd.Connection = con; //Used to establish connection to database
            con.ConnectionString = connstr;
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            cmd.CommandText = "sp_UpdateEmployee";
            cmd.Parameters.AddWithValue("id", employee.Id);
            cmd.Parameters.AddWithValue("name", employee.Name);
            cmd.Parameters.AddWithValue("gender", employee.Gender);
            cmd.Parameters.AddWithValue("location", employee.Location);
            cmd.Parameters.AddWithValue("salary", employee.Salary);
            con.Open();
            int rowcount = cmd.ExecuteNonQuery();
            con.Close();
            return rowcount;

        }

        public int DeleteEmployee(Employee employee)
        {

            cmd.Connection = con; //Used to establish connection to database
            con.ConnectionString = connstr;
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            cmd.CommandText = "sp_DeleteEmployeeById";
            cmd.Parameters.AddWithValue("id", employee.Id);

            con.Open();
            int rowcount = cmd.ExecuteNonQuery();
            con.Close();
            return rowcount;
        }
        public void ReadEmployee(Employee employee)
        {
            cmd.Connection = con; //Used to establish connection to database
            con.ConnectionString = connstr;
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            cmd.CommandText = "sp_RetriveAllEmployee";
            con.Open();
            SqlDataReader rdr = cmd.ExecuteReader();
            
            while (rdr.Read())
            {
                Console.WriteLine($" {rdr[0]} \t {rdr[1]} \t {rdr[2]} \t {rdr[3]}\t {rdr[4]}");
            }
            con.Close();

        }
    }
}
