﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shapes_Assignment
{
    class Program
    {
        static void Main(string[] args)
        {
            double s_sqr, w_rect, b_rect, h_trg, b_trg, r_circ;
            Console.Write("Enter Side of Square: ");
            s_sqr = double.Parse(Console.ReadLine());
            Console.WriteLine();
            Console.Write("Enter Length of Rectangle: ");
            w_rect= double.Parse(Console.ReadLine());
            Console.WriteLine();
            Console.Write("Enter Breadth of Rectangle: ");
            b_rect = double.Parse(Console.ReadLine());
            Console.WriteLine();
            Console.Write("Enter Height of Triangle: ");
            h_trg = double.Parse(Console.ReadLine());
            Console.WriteLine();
            Console.Write("Enter Base of Triangle: ");
            b_trg = double.Parse(Console.ReadLine());
            Console.WriteLine();
            Console.Write("Enter Radius of Circle: ");
            r_circ = double.Parse(Console.ReadLine());
            Console.WriteLine();

            Shapes area = new Shapes(s_sqr, w_rect, b_rect, h_trg, b_trg, r_circ);
            area.calculateArea();
            Console.ReadLine();

        }
    }
}
