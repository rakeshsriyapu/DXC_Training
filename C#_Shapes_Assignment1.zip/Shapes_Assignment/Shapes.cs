﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shapes_Assignment
{
    class Shapes
    {
        double s_sqr, w_rect, b_rect, h_trg, b_trg,r_circ;
        double a_sqr, a_rect, a_trg,a_circ;

        public void calculateArea()
        {
            a_sqr = s_sqr * s_sqr;
            a_rect = w_rect * b_rect;
            a_trg = 0.5 * h_trg * b_trg;
            a_circ = 3.14 * r_circ * r_circ;
            Console.WriteLine("Area of Square: " + a_sqr);
            Console.WriteLine("Area of Rectangle: "+a_rect);
            Console.WriteLine("Area of Triangle: " + a_trg);
            Console.WriteLine("Area of Circle: "+a_circ);
        }
        public Shapes(double s1_sqr,double w1_rect, double b1_rect,double h1_trg,double b1_trg,double r1_circ)
        {
            this.s_sqr = s1_sqr;
            this.w_rect = w1_rect;
            this.b_rect = b1_rect;
            this.h_trg = h1_trg;
            this.b_trg = b1_trg;
            this.r_circ = r1_circ;
        }
    }
}
